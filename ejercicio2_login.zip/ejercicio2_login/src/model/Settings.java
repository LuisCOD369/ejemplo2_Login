package model;

import libreriaVersion3.Connect;

public interface Settings 
{
	public Connect conn = new Connect ("Ejercicio2Login");
}
